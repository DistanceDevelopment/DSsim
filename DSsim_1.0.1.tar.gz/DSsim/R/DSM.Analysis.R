setClass(Class = "DSM.Analysis", representation(model = "call")
) 