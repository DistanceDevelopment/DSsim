#' @include LT.Design.R

################################################################################
# CONSTRUCT CLASS AND DEFINE INITIALIZE AND VALIDITY
################################################################################

setClass(Class = "LT.EqAngle.ZZ.Design", 
         contains = "LT.Design"
) 