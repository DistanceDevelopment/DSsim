#' @include LT.Design.R

################################################################################
# CONSTRUCT CLASS AND DEFINE INITIALIZE AND VALIDITY
################################################################################

setClass(Class = "LT.EqSpace.ZZ.Design", 
         contains = "LT.Design"
)    

