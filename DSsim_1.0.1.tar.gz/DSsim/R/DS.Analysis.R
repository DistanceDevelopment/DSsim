#' @include DDF.Analysis.R

setClass(Class = "DS.Analysis", 
         contains = "DDF.Analysis"
) 


