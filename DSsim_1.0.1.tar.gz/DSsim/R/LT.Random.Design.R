#' @include LT.Design.R

################################################################################
# CONSTRUCT CLASS AND DEFINE INITIALIZE AND VALIDITY
################################################################################

setClass(Class = "LT.Random.Design", 
         contains = "LT.Design"
) 