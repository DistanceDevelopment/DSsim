library(DSsim)
library(testthat)

context("Basic Example")

test_that("Input Checks", {
  
  
})
      