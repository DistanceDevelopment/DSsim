library(testthat)
library(DSsim)

test_package("DSsim")

